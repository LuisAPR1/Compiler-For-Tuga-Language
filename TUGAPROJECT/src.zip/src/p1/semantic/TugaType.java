package p1.semantic;

public enum TugaType {
    INT,
    REAL,
    BOOLEAN,
    STRING,
    ERROR;  // Representa um erro de tipo
}
